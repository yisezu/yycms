<?php
$tpl->show('index');
?>