<?php
define('YYCMS_VERSION','1.5');
define('YYCMS_HTVERSION','1.5');
?>