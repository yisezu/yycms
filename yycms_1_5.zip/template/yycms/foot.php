	<!--footer-->
    <div class="footer">
      <div class="wrap">
        <p>免责声明：若本站收录的资源侵犯了您的权益，请联系我们，我们会及时删除侵权内容，谢谢合作！</p>
        <p>Copyright &#169; 2012-2022 {yycms_url}. All Rights Reserved. {yycms_foot}{yycms_tj}</p>
      </div>
    </div>
<!--footer-->
    
    
    <div class="wrap">
      <div class="guide">
        <a href="/" title="123">
          <i class="icon-home">
          </i>
        </a>
        <div class="guide">
        <a href="/" title="首页"><i class="icon-home"></i></a><a href="javascript:scroll(0,0)" title="顶部"><i class="icon-top"></i></a>
        </div>
      </div>
    </div>
	