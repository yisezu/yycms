  <meta itemprop="url" property="og:url" content="https://<?php echo $_SERVER['HTTP_HOST'] ?>/vod/view/id/{yycmsobj_id}.html" />
  <meta itemprop="name" property="og:title" content="{yycmsobj_name}{yycms_title}" />
  <meta itemprop="type" property="og:type" content="video" />
  <meta itemprop="image" property="og:image" content="{yycmsobj_pic}" />
  <meta itemprop="releaseDate" property="og:release_date" content="{yycmsobj_time}"/>
  <meta itemprop="description" property="og:description" content="{yycmsobj_name}{yycms_description}" />
  <meta property="og:locale" content="zh-CN"/>
  <meta name="MSSmartTagsPreventParsing" content="True">
  <meta http-equiv="MSThemeCompatible" content="Yes">