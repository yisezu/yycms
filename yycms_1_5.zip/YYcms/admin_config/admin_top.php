<div class="layui-layout layui-layout-admin">
<div class="layui-header header header-demo">
  <div class="layui-fluid">
    <div class="pc">
    <a class="logo" href="../../" tppabs="https://www.zxyycms.com/">
      <img src="/assets/img/YYCMS.png" tppabs="https://www.zxyycms.com/YYCMS.png" alt="优优CMS">
    </a>
    </div>
    <ul class="layui-nav">
      <li class="layui-nav-item " href="javascript:;">
        <a href="/" target="_blank" rel="nofollow">网页前台</a>
      </li>
	  
      <li class="layui-nav-item ">
        <a href="//www.zxyycms.com"  target="_blank">优优官网</a>
      </li>
      
      <li class="layui-nav-item">
        <a href="javascript:;">
          清理缓存
        </a>
        <dl class="layui-nav-child" style="left: auto; right: -22px; text-align: center;">  
          <dd class="layui-hide-sm layui-show-xs" lay-unselect>
            <a href="/" target="_blank" rel="nofollow">网页前台</a>
            <hr>
          </dd>
          <dd lay-unselect><a href="javascript:;"  onclick="clean()">清除缓存</a> </dd>
		  <dd lay-unselect><a href="?err=1" >退出登录</a> </dd>
        </dl>
      </li>
    </ul>
  </div>
</div>