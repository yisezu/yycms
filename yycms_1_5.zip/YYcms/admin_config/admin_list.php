
<div class="layui-side layui-bg-black">
    <div class="layui-side-scroll">
      
<ul class="layui-nav layui-nav-tree site-demo-nav"  >
  <li class="layui-nav-item " >
    <a  href="../admin_index/">首页</a>
  </li>

      <li class="layui-nav-item layui-nav-itemed">
        <dd> 
        <a class="admin-nav-item" href="../admin_Basicsetup/Basicsetup.php">基本设置</a>
        </dd><dd> 
  	    <a href="../admin_Basicsetup/Advanced.php">高级设置</a>
  	    </dd><dd> 
	    <a href="../admin_connection/connection.php">友情链接</a>
	    </dd><dd> 
        <a href="../admin_ad/ad_top.php">头部横幅广告</a>
        </dd><dd> 
  	    <a href="../admin_ad/ad_video.php">播放横幅广告</a>
        </dd><dd> 
	    <a href="../admin_ad/ad_Couplets.php">对联展现广告</a>
	   </dd><dd> 
	    <a href="../admin_ad/ad_float.php">底部浮漂广告</a>
	   </dd><dd> 
	    <a href="../admin_ad/ad_js.php">广告联盟JS广告</a>
	   </dd><dd> 
	    <a href="../admin_ad/ad_Popup.php">每日弹窗广告</a>
	   </dd><dd> 
        <a href="../admin_security/security_Journal.php">登录日志</a>
       </dd><dd> 
  	    <a href="../admin_security/security_userpass.php">登录重置</a>
  	   </dd><dd> 
  	    <a href="../admin_security/security_301.php">301重定向</a>
  	   </dd><dd> 
        <a href="../admin_qita/SiteGroup_list.php">站群管理</a>
       </dd><dd> 
  	    <a href="../admin_qita/qita_dizhi.php">地址公告设置</a>
  	   </dd><dd> 
        <a href="../admin_plug/myplug.php">我的扩展</a>
       </dd><dd> 
  	    <a href="../admin_plug/template.php?page=1">模板安装</a>
  	   </dd><dd> 
  	    <a href="../admin_plug/plug.php">插件安装</a>
  	   </dd>
    </dl>
  </li>
</ul>


    </div>
  </div>
  
<div class="site-tree-mobile layui-hide">
  <i class="layui-icon layui-icon-spread-left"></i>
</div>

    <div class="layui-tab layui-tab-brief" lay-filter="demoTitle">
      <div class="layui-body layui-tab-content site-demo site-demo-body ">
        <div class="layui-container">