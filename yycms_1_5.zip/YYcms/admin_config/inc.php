    <!--优优CMS-->
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>优优CMS管理中心</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"> 
    <meta name="apple-mobile-web-app-status-bar-style" content="black"> 
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="format-detection" content="telephone=no">
    <link rel="icon" type="image/png" href="<?php echo YYCMS_ADMIN_url;?>assets/img/favicon.ico">
	<link rel="stylesheet" href="<?php echo YYCMS_ADMIN_url;?>assets/css/layui.css?v=2">
	<link rel="stylesheet" href="<?php echo YYCMS_ADMIN_url;?>assets/css/global.css?v=522212">
	<script src="<?php echo YYCMS_ADMIN_url;?>assets/layui.js" charset="utf-8"></script>