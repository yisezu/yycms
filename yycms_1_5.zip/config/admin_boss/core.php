<?php
return array (
  'username' => '123456',
  'password' => '123456',
  'ippass' => '',
);