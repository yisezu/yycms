<?php
//后台密码
define('USERNAME', '123456');
define('PASSWORD', '123456');
define('IPPASS', '');
?>